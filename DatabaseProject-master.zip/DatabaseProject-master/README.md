# DatabaseProject

In this project I tried to compare the performance of an sql(postgresql) and a no-sql(orientdb) database. 
I used stack-Overflow dataset in this purpose.
The java codes contain codes to establish a connection to the database, creating a table, parsing the xml file, and inserting 
the data in the table.
